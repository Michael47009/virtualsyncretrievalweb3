<?php
    include "cdn.php";

?><h1>not found on this server</h1>
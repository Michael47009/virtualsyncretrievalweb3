<?php include 'cdn.php'; ?>
<style>
    .full { color:#9A9DA0; float: right; width: 45%; white-space: nowrap; padding:2%; font-weight:400; transform:scale(1.02)}
  .section-one { width:100%; background:#000000; }
</style>
<div class="section-one" style='background:#000000;'>
    <span style='color:#000000'>testing</span>
    <div class="full" > 
    <span style='text-align:left;font-size:17px;' ><a href='/signup'> Sign up</a></span><span style='padding-left:10%;text-align:right; font-size:17px;'><a href='/signin/auth'> Sigin in</a> <i class="fa fa-sign-in"></i> </span>
    </div>
    <br> <span style='color:#000000'>testing</span>
</div>  
</div>
<div class="header">
  <div class="left"><b style='color:orange'>VirtualSync</b></div>
  <div class="right">
    
 
  <button style="font-size:25px; " onclick="openNav()"> <i class="fa fa-bars" style='color:#ccc;'></i></button>
<style>
  .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="/" style='color:orange;'>Home</a>
  <a href="/about" style='color:orange;'>About</a>
  <a href="/service" style='color:orange;'>Services</a>
  <a href="/contact" style='color:orange;'>Contact</a>
</div>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
   
    

</div>
</div>
<style>
.header { background:#343A40; padding:7%; padding-bottom:10%;} .left { float:left; font-size:27px; color:orangered; margin-left:-4%; transform:scale(0.9); margin-top:-3%;}
.right { float:right; margin-top:-3%; margin-left:-25%; }.right button { background:#343A40; border:hidden; padding:53%; }
  </style>

  <div class="header_two">
  <style>
.container {
  position: relative;
  text-align: center;
  color: white;
}

.bottom-left {
  position: absolute;
  bottom: 8px;
  left: 16px;
}

.top-left {
  position: absolute;
  top: 8px;
  left: 16px;
}

.top-right {
  position: absolute;
  top: 8px;
  right: 16px;
}

.bottom-right {
  position: absolute;
  bottom: 8px;
  right: 16px;
}

.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.container img {
  margin-left:-10%;
}
body {
  font-family:'Roboto', sans-serif !important;
} .strt {
  border:hidden; border-radius:30px; padding:5%; width:50%; color:white; background:orange;
}
</style>

<div class="container">
  <img src="https://crypto-surge.com/images/bg1.jpg" alt="Snow" style="width:115%; opacity:0.9; height:70%; filter: brightness(50%);">
  <div class="bottom-left"></div>
 
  <div class="centered">
        <div class="contentt">
            <h1 style='font-weight:600; font-size:45px; color:orange'>Embrace the<br>Future of<br>Decentralized<br>Finance.</h1>
            <p style='font-weight:400; font-size:17px;'>Join the revolution with Web3 and blockchain technology</p>
            <a href='/signup'>  <button class='strt'>Get Started</button></a>
        </div>

</div>
</div>
  </div>

  <style> .con {letter-spacing:-0.5px; padding:5%; background:#ccc; display: block; margin:auto; margin-left:-8%; width:123%; border-radius:10px; }
  .con h4 { font-weight:700;} .cc {  column-count:2;}
  .foot { text-align:center; background:#101010; color:gray; padding:5%; font-size:18px;}  </style>
  <div class="thirdd" style='background:#e6e6e6; padding:14%; width:103%; margin-left:-4%; text-align:center;'>


  <div class="con">
    <i class="fa fa-lock" style="font-size:58px;color:orange"></i><br>
      <h4>Secure Transactions</h4>
      <p style='font-weight:400; font-size:17px;'> Experience the highest level of security in the crypto world</p>
    </div>

    <br>
    <div class="con">
    <i class="fa fa-bar-chart-o" style="font-size:48px;color:orange"></i><br>
      <h4>Decentralized Finance</h4>
      <p style='font-weight:400; font-size:17px;'>Take control of your assets withous intermediaries.</p>
    </div>
    <br>
    <div class="con">
    <i class="fa fa-bank" style="font-size:48px;color:orange"></i><br>
      <h4>Wallet Integration</h4>
      <p style='font-weight:400; font-size:17px;'> Seemlessly connect your crypto wallets for easy access.</p>
    </div>


  </div>

  <div class="foot">
    <div class="cc">
    <div class="lf" style=''>Privacy policy </div>
    <div class="rg">Terms of service</div>

    </div>
   <br>
    <p><b>
    @2025 Virtual-Sync. All rights reserved.</b></p>

  
  </div>
  
<?php include 'cdn.php'; ?>
<style>
    .full { color:#9A9DA0; float: right; width: 45%; white-space: nowrap; padding:2%; font-weight:400; transform:scale(1.02)}
  .section-one { width:100%; background:#000000; }
</style>
<div class="section-one" style='background:#000000;'>
    <span style='color:#000000'>testing</span>
    <div class="full" > 
    <span style='text-align:left;font-size:17px;' ><a href='/signup'> Sign up</a></span><span style='padding-left:10%;text-align:right;font-size:17px;'><a href='/signin/auth'> Sigin in</a> <i class="fa fa-sign-in"></i> </span>
    </div>
    <br> <span style='color:#000000'>testing</span>
</div>  
</div>
<div class="header">
  <div class="left"><b style='color:orange'>VirtualSync</b></div>
  <div class="right">
   
  <button style="font-size:25px; " onclick="openNav()"> <i class="fa fa-bars" style='color:#ccc;'></i></button>
<style>
  .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="/" style='color:orange;'>Home</a>
  <a href="/about" style='color:orange;'>About</a>
  <a href="/service" style='color:orange;'>Services</a>
  <a href="/contact" style='color:orange;'>Contact</a>
</div>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
   
    

</div>
</div>
<style>
.header { background:#343A40; padding:7%; padding-bottom:10%;} .left { float:left; font-size:27px; color:orangered; margin-left:-4%; transform:scale(0.9); margin-top:-3%;}
.right { float:right; margin-top:-3%; margin-left:-25%; }.right button { background:#343A40; border:hidden; padding:53%; }
  </style>

  <div class="header_two">
  <style>
.container {
  position: relative;
  text-align: center;
  color: white;
}

.bottom-left {
  position: absolute;
  bottom: 8px;
  left: 16px;
}

.top-left {
  position: absolute;
  top: 8px;
  left: 16px;
}

.top-right {
  position: absolute;
  top: 8px;
  right: 16px;
}

.bottom-right {
  position: absolute;
  bottom: 8px;
  right: 16px;
}

.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.container img {
  margin-left:-10%;
}
body {
  font-family:'Roboto', sanss-serif !important;
} .strt {
  border:hidden; border-radius:30px; padding:5%; width:50%; color:white; background:orange;
}
</style>

<div class="container">
  <img src="https://crypto-surge.com/images/bg2.jpg" alt="Snow" style="width:115%; opacity:0.9; height:35%;  filter: brightness(50%);">
  <div class="bottom-left"></div>
 
  <div class="centered">
        <div class="contentt">
            <h1 style='font-weight:600; font-size:50px; color:orange'>Contact Us.</h1>
         
           
        </div>

</div>
</div>


<style>
.next { padding:5%;}
.frm { padding:5%; background:#dcdcdc; border-radius:13px; display:block; margin:auto}
input { border:hidden; border:1px solid #ccc; padding:4%; width:100%; border-radius:7px;
} textarea { border:hidden; border:1px solid #ccc;}
button { border:hidden;background:orange; color:white; border-radius:17px; width:45%; padding:4%;}
    </style>
<div class="next"><br><br>
<h2 style='font-weight:600; font-size:40px'>Get in Touch</h2>
    <p style='text-align:left; font-size:18px; width:96%; letter-spacing:-0.5px'>We’re here to help! Whether you have a question about our services, need assistance, or have feedback, feel free to reach out to us through the form below or via live chat for instant support.</p>
    <br>

    <div class="frm"><br>
        <label>Your Name</label><br>
        <input type='text'><br><br>

        <label>Your Email</label><br>
        <input type='email'><br><br>

        <label>Your Message</label><br>
        <textarea  rows="5" cols="40">

</textarea><br><br>
<button>Send Message</button>
    </div>

<br>
     <div class="frm"><br>
     <i class="fa fa-wechat" style="font-size:58px;color:black;"></i>
     <h2 style='font-weight:600; font-size:30px'>Chat With Us Live </h2>
    <p style='text-align:left; font-size:18px; width:96%; letter-spacing:-0.5px'>If you need immediate assistance, our team is available via live chat to help you with any queries or issues.
<br><br>
Simply click the chat icon on the bottom right of the page to start chatting with a representative now!
.</p>
    <br>
<br>
    <div class="frm">
    <h2 style='font-weight:600; font-size:35px'>Email Us</h2>
    <p style='text-align:left; font-size:18px; width:96%; letter-spacing:-0.5px'>If you'd prefer to contact us via email, feel free to reach out at:<br>
<b>
support@virtualsync.com</b></p>
    <br>
    </div>
  
<br>
    </div>



</div>











<br><br>
<div class="foot">
    <div class="cc">
    <div class="lf" style=''>Privacy policy </div>
    <div class="rg">Terms of service</div>

    </div>
   <br>
    <p><b>
    @2025 Virtual-Sync. All rights reserved.</b></p>

  
  </div><style>
     .cc {  column-count:2;}
     .foot {margin-left:-6%; height:20%;
      width:115%; text-align:center; background:#101010; color:gray; padding:5%; font-size:18px;
      margin-bottom:-20%;}</style>
